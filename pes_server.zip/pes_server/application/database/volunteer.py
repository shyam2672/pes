class volunteer:
    def __init__(self,pid,pwd):
        
        self.PES_ID = pid
        self.Password=pwd
        self.Name=''
        self.Phone=''
        self.Profession =''
        self.Email =''
        self.address=''
        self.Pathshaala =''
        self.Token=''
        self.Status='Active'
        self.joining_date=''

